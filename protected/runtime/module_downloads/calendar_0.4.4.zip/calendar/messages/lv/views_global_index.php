<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filtrēt</strong> notikumus',
  '<strong>Select</strong> calendars' => '<strong>Izvēlēties</strong> kalendārus',
  'Already responded' => 'Jau atbildēja',
  'Followed spaces' => 'Sekotās vietas',
  'Followed users' => 'Sekotie lietotāji',
  'I´m attending' => 'Es piedalos',
  'My events' => 'Mani notikumi',
  'My profile' => 'Mans profils',
  'My spaces' => 'Manas vietas',
  'Not responded yet' => 'Nav vēl atbildēts',
);
