<?php
return array (
  '<strong>Create</strong> event' => '<strong>Izveidot</strong> pasākumu',
  '<strong>Edit</strong> event' => '<strong>Rediģēt</strong> pasākumu',
  '<strong>Note:</strong> This event will be created on your profile. To create a space event open the calendar on the desired space.' => '<strong>Piezīme:</strong> Šis notikums tiks izveidots tavā profilā. Lai izveidotu vietas notikumu, atver kalendāru vēlamajā vietā.',
  'Close' => 'Aizvērt',
  'Delete' => 'Dzēst',
  'Description' => 'Apraksts',
  'End Date/Time' => 'Beigu datums/laiks',
  'Everybody can participate' => 'Visi var piedalīties',
  'No participants' => 'Nav dalībnieku',
  'Participants' => 'Dalībnieki',
  'Save' => 'Saglabāt',
  'Title' => 'Nosaukum',
);
