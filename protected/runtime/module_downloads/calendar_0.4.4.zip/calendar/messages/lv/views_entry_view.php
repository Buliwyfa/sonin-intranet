<?php
return array (
  'Attend' => 'Piedalīties',
  'Decline' => 'Noraidīt',
  'Edit event' => 'Rediģēt pasākumu',
  'Maybe' => 'Varbūt',
);
