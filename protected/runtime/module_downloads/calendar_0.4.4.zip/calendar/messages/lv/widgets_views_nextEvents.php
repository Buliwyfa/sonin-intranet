<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Gaidāmie</strong> notikumi',
);
