<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% piedalīsies %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% varbūt piedalīsies %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% nepiedalīsies %contentTitle%.',
);
