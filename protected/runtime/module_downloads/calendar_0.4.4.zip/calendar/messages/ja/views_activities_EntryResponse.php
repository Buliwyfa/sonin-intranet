<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName%さんは、%contentTitle%に参加します。',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName%さんは、おそらく%contentTitle%に参加します。',
  '%displayName% not attends to %contentTitle%.' => '%displayName%さんは、%contentTitle%に参加しません。',
);
