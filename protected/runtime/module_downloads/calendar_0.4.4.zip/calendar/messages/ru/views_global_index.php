<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Фильтровать</strong> события',
  '<strong>Select</strong> calendars' => '<strong>Выбор</strong> календаря',
  'Already responded' => 'Уже отвечено',
  'Followed spaces' => 'Пространства, за которыми слежу',
  'Followed users' => 'Пользователи, за которыми слежу',
  'I´m attending' => 'Я собираюсь посетить',
  'My events' => 'Мои события',
  'My profile' => 'Мой профиль',
  'My spaces' => 'Мои пространства',
  'Not responded yet' => 'Пока без ответа',
);
