<?php
return array (
  'Attend' => 'Asistir',
  'Decline' => 'No asistir',
  'Edit event' => 'Editar Evento',
  'Maybe' => 'Tal vez',
);
