<?php
return array (
  'Attend' => 'Hadir',
  'Decline' => 'Batal',
  'Edit event' => 'Ubah Acara',
  'Maybe' => 'Mungkin',
);
