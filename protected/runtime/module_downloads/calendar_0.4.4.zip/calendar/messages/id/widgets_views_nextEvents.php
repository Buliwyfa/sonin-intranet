<?php
return array (
  '<strong>Upcoming</strong> events ' => 'Acara Selanjutnya',
);
