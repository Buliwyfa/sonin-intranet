<?php
return array (
  '<strong>Create</strong> event' => 'buat acara',
  '<strong>Edit</strong> event' => 'Ubah acara',
  '<strong>Note:</strong> This event will be created on your profile. To create a space event open the calendar on the desired space.' => 'Catatan: acara ini akan dibuat di profil kamu. Untuk membuat acara di ruang kamu bisa membuka kalender di ruang kamu',
  'Close' => 'Tutup',
  'Delete' => 'Hapus',
  'Description' => 'Deskripsi',
  'End Date/Time' => 'Tanggal/Waktu berakhir',
  'Everybody can participate' => 'Semua orang dapat berpartisipasi',
  'No participants' => 'Tidak berpartisipasi',
  'Participants' => 'Partisipasi',
  'Save' => 'Simpan',
  'Title' => 'Judul',
);
