<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Viitoare</strong> evenimente',
);
