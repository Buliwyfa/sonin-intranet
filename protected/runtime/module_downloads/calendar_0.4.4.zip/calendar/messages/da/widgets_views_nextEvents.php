<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Kommende</strong> events',
);
