<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filter</strong> events',
  '<strong>Select</strong> calendars' => '<strong>Vælg</strong> Kalendere',
  'Already responded' => 'Allerede svaret',
  'Followed spaces' => 'Fulgte sider',
  'Followed users' => 'Fulgte brugere',
  'I´m attending' => 'Jeg deltager',
  'My events' => 'Mine events',
  'My profile' => 'Min profil',
  'My spaces' => 'Mine Sider',
  'Not responded yet' => 'Ikke svaret endnu',
);
