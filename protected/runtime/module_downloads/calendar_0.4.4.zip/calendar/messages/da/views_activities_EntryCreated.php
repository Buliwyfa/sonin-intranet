<?php
return array (
  '%displayName% created a new %contentTitle%.' => '%displayName% oprettede et nyt %contentTitle%.',
);
