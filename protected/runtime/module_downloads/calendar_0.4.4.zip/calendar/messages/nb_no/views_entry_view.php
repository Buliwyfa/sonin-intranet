<?php
return array (
  'Attend' => 'Delta',
  'Decline' => 'Avvis',
  'Edit event' => 'Redigér event',
  'Maybe' => 'Kanskje',
);
