<?php
return array (
  '<strong>Create</strong> event' => '<strong>Opprett</strong> event',
  '<strong>Edit</strong> event' => '<strong>Rediger</strong> event',
  '<strong>Note:</strong> This event will be created on your profile. To create a space event open the calendar on the desired space.' => '<strong>Merk:</strong> Denne eventen blir lagt til på din profil. For å legge til en gruppeevent åpner du kalenderen i den ønskede gruppen.',
  'Close' => 'Lukk',
  'Delete' => 'Slett',
  'Description' => 'Beskrivelse',
  'End Date/Time' => 'Slutt dato & tid',
  'Everybody can participate' => 'Alle kan delta',
  'No participants' => 'Ingen deltagere',
  'Participants' => 'Deltagere',
  'Save' => 'Lagre',
  'Title' => 'Tittel',
);
