<?php
return array (
  'Attend' => 'حضور',
  'Decline' => 'انصراف',
  'Edit event' => 'ویرایش رویداد',
  'Maybe' => 'احتمالا',
);
