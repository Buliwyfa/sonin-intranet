<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% در %contentTitle% حضور دارد.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% احتمالا در %contentTitle% حضور دارد.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% در %contentTitle% حضور ندارد.',
);
