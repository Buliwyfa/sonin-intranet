<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Nadcházející</strong> události',
);
