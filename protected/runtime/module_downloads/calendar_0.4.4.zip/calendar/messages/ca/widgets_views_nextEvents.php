<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Pròxims</strong> esdeveniments ',
);
