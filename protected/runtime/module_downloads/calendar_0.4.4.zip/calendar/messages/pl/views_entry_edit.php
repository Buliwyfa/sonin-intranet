<?php
return array (
  '<strong>Create</strong> event' => '<strong>Utwórz</strong> wydarzenie',
  '<strong>Edit</strong> event' => '<strong>Edytuj</strong> wydarzenie',
  '<strong>Note:</strong> This event will be created on your profile. To create a space event open the calendar on the desired space.' => '<strong>Zauważ:</strong> To wydarzenie zostanie utworzone na twoim profilu. Aby utworzyć wydarzenie dla strefy otwórz kalendarz w wybranej strefie.',
  'Close' => 'Zamknij',
  'Delete' => 'Usuń',
  'Description' => 'Opis',
  'End Date/Time' => 'Data/czas zakończenia',
  'Everybody can participate' => 'Każdy może wziąć udział',
  'No participants' => 'Brak biorących udział',
  'Participants' => 'Uczestnicy',
  'Save' => 'Zapisz',
  'Title' => 'Tytuł',
);
