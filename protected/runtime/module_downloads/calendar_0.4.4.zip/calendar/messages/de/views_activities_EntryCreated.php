<?php
return array (
  '%displayName% created a new %contentTitle%.' => '%displayName% hat einen neuen Termin »%contentTitle%« erstellt.',
);
