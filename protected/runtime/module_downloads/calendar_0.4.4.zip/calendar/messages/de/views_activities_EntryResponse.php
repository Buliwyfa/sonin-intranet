<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% nimmt an »%contentTitle%« teil.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% nimmt vielleicht an »%contentTitle%« teil.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% nimmt nicht an »%contentTitle%« teil.',
);
