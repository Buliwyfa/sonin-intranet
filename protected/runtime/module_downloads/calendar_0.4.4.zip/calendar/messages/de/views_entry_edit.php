<?php
return array (
  '<strong>Create</strong> event' => 'Termin <strong>erstellen</strong>',
  '<strong>Edit</strong> event' => 'Termin <strong>bearbeiten</strong>',
  '<strong>Note:</strong> This event will be created on your profile. To create a space event open the calendar on the desired space.' => '<strong>Beachte:</strong> Dieser Termin wird in deinem Profil erstellt. Um einen Termin in einem Space zu erstellen, öffne den Kalender im gewünschten Space.',
  'Close' => 'Schließen',
  'Delete' => 'Löschen',
  'Description' => 'Beschreibung',
  'End Date/Time' => 'Enddatum/Endzeit',
  'Everybody can participate' => 'Jeder darf teilnehmen',
  'No participants' => 'Keine Teilnehmer',
  'Participants' => 'Teilnehmer',
  'Save' => 'Speichern',
  'Title' => 'Titel',
);
