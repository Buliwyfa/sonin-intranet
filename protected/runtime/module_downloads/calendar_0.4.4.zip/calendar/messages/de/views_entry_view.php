<?php
return array (
  'Attend' => 'Teilnehmen',
  'Decline' => 'Absagen',
  'Edit event' => 'Termin bearbeiten',
  'Maybe' => 'Vielleicht',
);
