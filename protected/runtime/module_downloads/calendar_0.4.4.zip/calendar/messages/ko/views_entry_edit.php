<?php
return array (
  '<strong>Create</strong> event' => '',
  '<strong>Edit</strong> event' => '',
  '<strong>Note:</strong> This event will be created on your profile. To create a space event open the calendar on the desired space.' => '',
  'Close' => '닫기',
  'Delete' => '',
  'Description' => '',
  'End Date/Time' => '',
  'Everybody can participate' => '',
  'No participants' => '',
  'Participants' => '',
  'Save' => '',
  'Title' => '제목',
);
