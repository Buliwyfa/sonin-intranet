<?php
return array (
  '<strong>Create</strong> event' => '',
  '<strong>Edit</strong> event' => '',
  '<strong>Note:</strong> This event will be created on your profile. To create a space event open the calendar on the desired space.' => '',
  'Close' => 'اغلاق',
  'Delete' => 'حذف',
  'Description' => 'توضيج',
  'End Date/Time' => '',
  'Everybody can participate' => '',
  'No participants' => '',
  'Participants' => '',
  'Save' => 'حفظ',
  'Title' => 'العنوان',
);
