<?php
return array (
  'Attend' => '',
  'Decline' => 'رفض',
  'Edit event' => '',
  'Maybe' => '',
);
