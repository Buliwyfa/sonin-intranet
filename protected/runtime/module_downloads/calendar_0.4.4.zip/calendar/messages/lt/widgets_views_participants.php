<?php
return array (
  ':count attending' => ': suskaičiuota dalyvaujančiu',
  ':count declined' => ': suskaičiuota atsisakiusiu dalyvauti',
  ':count maybe' => ': suskaičiuota galbūt dalyvausiančiu',
  'Participants:' => 'Dalyviai:',
);
