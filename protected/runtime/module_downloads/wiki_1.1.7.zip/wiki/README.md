## Description

Adds a wiki pages to space / user profiles

v.1.1.3:
    - Enh: Added ViewHistory Permission


__Module website:__ <https://github.com/humhub/humhub-modules-wiki>  
__Author:__ luke, andystrobel  
__Author website:__ [humhub.org](http://humhub.org)
