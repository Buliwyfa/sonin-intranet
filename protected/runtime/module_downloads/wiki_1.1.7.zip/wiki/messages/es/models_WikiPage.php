<?php
return array (
  'Wiki page' => 'Página de la wiki',
);
