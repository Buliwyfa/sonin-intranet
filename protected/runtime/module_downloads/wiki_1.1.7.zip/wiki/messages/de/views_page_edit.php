<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Erstelle</strong> eine neue Seite',
  '<strong>Edit</strong> page' => '<strong>Bearbeite</strong> eine Seite',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Gebe einen Wiki-Namen oder eine URL (z.B. http://example.com) ein',
  'New page title' => 'Neuer Seitentitel',
  'Page content' => 'Seiteninhalt',
  'Save' => 'Speichern',
);
