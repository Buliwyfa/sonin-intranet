<?php
return array (
  'Wiki page' => 'Wiki puslapis',
);
