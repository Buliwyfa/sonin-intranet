<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Opprett</strong> side',
  '<strong>Edit</strong> page' => '<strong>Rediger</strong> side',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Sett inn wiki sidetittel eller url (f.eks. http://example.com)',
  'New page title' => 'Ny sidetittel',
  'Page content' => 'Sideinnhold',
  'Save' => 'Lagre',
);
