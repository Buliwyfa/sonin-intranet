<?php
return array (
  '<strong>Create</strong> new page' => '',
  '<strong>Edit</strong> page' => '',
  'Enter a wiki page name or url (e.g. http://example.com)' => '',
  'New page title' => '',
  'Page content' => '',
  'Save' => 'Spara',
);
