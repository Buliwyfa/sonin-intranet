<?php
return array (
  'Open wiki page...' => 'Открыть страницу вики...',
);
