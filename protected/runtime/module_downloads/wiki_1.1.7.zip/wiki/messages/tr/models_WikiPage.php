<?php
return array (
  'Wiki page' => 'Wiki sayfası',
);
