<?php
return array (
  'Wiki page' => 'Pagina Wiki',
);
