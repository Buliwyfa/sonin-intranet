<?php
return array (
  'Created At' => 'Postet',
  'Created By' => 'Skrevet av',
  'Is Originator' => 'Er forfatter',
  'Last Viewed' => 'Sist sett',
  'Message' => 'Melding',
  'Messages' => 'Meldinger',
  'Title' => 'Tittel',
  'Updated At' => 'Oppdatert',
  'Updated By' => 'Oppdatert av',
  'User' => 'Bruker',
);
