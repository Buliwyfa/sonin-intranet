<?php
return array (
  'Conversations' => 'Conversazioni',
  'New' => 'Nuovo',
  'New message' => 'Nuovo messaggio',
  'There are no messages yet.' => 'Non c\'è alcun altro messaggio.',
);
