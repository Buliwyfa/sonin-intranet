<?php
return array (
  'Add recipients' => 'Aggiungi destinatari',
  'Close' => 'Chiudi',
  'New message' => 'Nuovo messaggio',
  'Send' => 'Invia',
);
