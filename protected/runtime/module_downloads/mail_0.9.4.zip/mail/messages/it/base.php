<?php
return array (
  'Created At' => 'Creato il',
  'Created By' => 'Creato da',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => 'Messaggio',
  'Messages' => 'Messaggi',
  'Title' => 'Titolo',
  'Updated At' => 'Aggiornato il',
  'Updated By' => 'Aggiornato da',
  'User' => 'Utente',
);
