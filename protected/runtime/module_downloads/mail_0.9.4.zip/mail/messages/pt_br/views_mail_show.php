<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => '<strong>Confirmar</strong> apagar conversa',
  '<strong>Confirm</strong> leaving conversation' => '<strong>Confirmar</strong> deixar conversa',
  '<strong>Confirm</strong> message deletion' => '<strong>Confirmar</strong> apagar mensagem',
  'Add user' => 'Adicionar usuário',
  'Cancel' => 'Cancelar',
  'Delete' => 'Apagar',
  'Delete conversation' => 'Apagar conversa',
  'Do you really want to delete this conversation?' => 'Você quer realmente apagar esta conversa?',
  'Do you really want to delete this message?' => 'Você realmente quer apagar esta mensagem?',
  'Do you really want to leave this conversation?' => 'Você quer realmente sair desta conversa?',
  'Leave' => 'Sair',
  'Leave conversation' => 'Deixar conversa',
  'Leave discussion' => 'Deixar discussão',
  'Send' => 'Enviar',
  'There are no messages yet.' => 'Não há mensagens ainda.',
  'Write an answer...' => 'Escreva uma resposta ...',
);
