<?php
return array (
  'Created At' => 'Criado Em',
  'Created By' => 'Criado Por',
  'Is Originator' => 'É Originador',
  'Last Viewed' => 'Última Visualização',
  'Message' => 'Mensagem',
  'Messages' => 'Mensagens',
  'Title' => 'Título',
  'Updated At' => 'Atualizado Em',
  'Updated By' => 'Atualizado Por',
  'User' => 'Usuário',
);
