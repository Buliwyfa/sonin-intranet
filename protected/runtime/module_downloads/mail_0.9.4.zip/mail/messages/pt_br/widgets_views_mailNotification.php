<?php
return array (
  'Messages' => 'Mensagens',
  'New message' => 'Nova mensagem',
  'Show all messages' => 'Mostrar todas as mensagens',
);
