<?php
return array (
  'Recipient' => 'Destinatário',
  'You cannot send a email to yourself!' => 'Você NÃO PODE enviar um e-mail para si mesmo!',
);
