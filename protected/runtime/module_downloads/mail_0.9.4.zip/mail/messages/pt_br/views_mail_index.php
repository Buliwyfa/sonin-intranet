<?php
return array (
  'Conversations' => 'Conversas',
  'New' => 'Nova',
  'New message' => 'Nova mensagem',
  'There are no messages yet.' => 'Não há mensagens ainda.',
);
