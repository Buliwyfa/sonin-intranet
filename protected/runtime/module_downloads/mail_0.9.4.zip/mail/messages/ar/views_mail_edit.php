<?php
return array (
  'Edit message entry' => 'تعديل محتوي الرسالة',
  'Save' => 'حفظ',
);
