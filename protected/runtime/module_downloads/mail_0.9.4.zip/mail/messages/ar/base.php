<?php
return array (
  'Created At' => '',
  'Created By' => 'تم وضعه بواسطة',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => 'الرسالة',
  'Messages' => 'الرسائل',
  'Title' => 'العنوان',
  'Updated At' => '',
  'Updated By' => '',
  'User' => 'المستخدم',
);
