<?php
return array (
  'Recipient' => 'المستلم',
  'You cannot send a email to yourself!' => '',
);
