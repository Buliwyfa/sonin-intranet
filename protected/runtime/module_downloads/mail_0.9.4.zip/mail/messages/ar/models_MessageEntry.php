<?php
return array (
  'New message in discussion from %displayName%' => 'رسالة جديدة في المناقشة بواسطة %displayName%',
);
