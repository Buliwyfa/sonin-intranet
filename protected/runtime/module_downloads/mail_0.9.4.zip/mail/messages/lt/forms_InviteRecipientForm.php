<?php
return array (
  'Recipient' => 'Gavėjas',
  'You cannot send a email to yourself!' => '',
);
