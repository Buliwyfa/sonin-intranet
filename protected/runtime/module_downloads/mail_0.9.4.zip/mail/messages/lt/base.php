<?php
return array (
  'Created At' => 'Sukurta (kada)',
  'Created By' => 'Sukurta (kieno)',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => 'Žinutė',
  'Messages' => 'Žinutės',
  'Title' => 'Pavadinimas',
  'Updated At' => 'Atnaujinta (kada)',
  'Updated By' => '',
  'User' => 'Vartotojas',
);
