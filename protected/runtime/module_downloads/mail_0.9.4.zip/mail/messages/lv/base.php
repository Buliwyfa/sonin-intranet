<?php
return array (
  'Created At' => 'Izveidota',
  'Created By' => 'Izveidoja',
  'Is Originator' => 'Ir iniciātors',
  'Last Viewed' => 'Pēdējo reizi skatīts',
  'Message' => 'Ziņa',
  'Messages' => 'Ziņas',
  'Title' => 'Nosaukums',
  'Updated At' => 'Atjaunots',
  'Updated By' => 'Atjaunoja',
  'User' => 'Lietotājs',
);
