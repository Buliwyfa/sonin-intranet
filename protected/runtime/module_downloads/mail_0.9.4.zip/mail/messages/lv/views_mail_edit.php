<?php
return array (
  'Edit message entry' => 'Labot ziņas ierakstu',
  'Save' => 'Saglabāt',
);
