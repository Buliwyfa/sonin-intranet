<?php
return array (
  'Conversations' => 'Sarunas',
  'New' => 'Jauns',
  'New message' => 'Jauna ziņa',
  'There are no messages yet.' => 'Šeit vēl nav nevienas ziņas.',
);
