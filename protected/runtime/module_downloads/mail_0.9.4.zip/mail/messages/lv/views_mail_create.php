<?php
return array (
  'Add recipients' => 'Pievieno saņēmējus',
  'Close' => 'Aizvērt',
  'New message' => 'Jauna ziņa',
  'Send' => 'Sūtīt',
);
