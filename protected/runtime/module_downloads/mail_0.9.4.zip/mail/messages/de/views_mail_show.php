<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => '<strong>Bestätige</strong> Löschung der Konversation',
  '<strong>Confirm</strong> leaving conversation' => '<strong>Bestätige</strong> Verlassen der Konversation',
  '<strong>Confirm</strong> message deletion' => '<strong>Bestätige</strong> Löschung der Nachricht ',
  'Add user' => 'Füge Empfänger hinzu',
  'Cancel' => 'Abbrechen',
  'Delete' => 'Löschen',
  'Delete conversation' => 'Konversation löschen',
  'Do you really want to delete this conversation?' => 'Willst du diese Konversation wirklich löschen?',
  'Do you really want to delete this message?' => 'Willst du diese Nachricht wirklich löschen?',
  'Do you really want to leave this conversation?' => 'Willst du die Unterhaltung wirklich verlassen?',
  'Leave' => 'Verlassen',
  'Leave conversation' => 'Konversation verlassen',
  'Leave discussion' => 'Verlasse die Diskussion',
  'Send' => 'Senden',
  'There are no messages yet.' => 'Derzeit keine Nachrichten vorhanden.',
  'Write an answer...' => 'Schreibe eine Antwort ...',
);
