<?php
return array (
  'Recipient' => 'Destinataire',
  'You cannot send a email to yourself!' => 'Vous ne pouvez pas envoyer un e-mail à vous-même.',
);
