<?php
return array (
  'Created At' => 'Créé le',
  'Created By' => 'Créé par',
  'Is Originator' => 'Est à l\'origine',
  'Last Viewed' => 'Dernière lecture',
  'Message' => 'Message',
  'Messages' => 'Messages',
  'Title' => 'Titre',
  'Updated At' => 'Mis à jour le',
  'Updated By' => 'Mis à jour par',
  'User' => 'Utilisateur',
);
