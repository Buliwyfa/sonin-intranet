<?php
return array (
  'Created At' => '',
  'Created By' => '',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => 'Mesaj',
  'Messages' => '',
  'Title' => 'Titlul',
  'Updated At' => '',
  'Updated By' => '',
  'User' => '',
);
