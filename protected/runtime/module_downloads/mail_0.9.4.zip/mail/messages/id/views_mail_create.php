<?php
return array (
  'Add recipients' => '',
  'Close' => 'Tutup',
  'New message' => '',
  'Send' => '',
);
