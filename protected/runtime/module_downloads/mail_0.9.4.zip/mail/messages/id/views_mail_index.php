<?php
return array (
  'Conversations' => '',
  'New' => 'Baru',
  'New message' => '',
  'There are no messages yet.' => '',
);
