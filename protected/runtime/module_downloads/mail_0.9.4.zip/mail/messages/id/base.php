<?php
return array (
  'Created At' => '',
  'Created By' => '',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => '',
  'Messages' => '',
  'Title' => 'Judul',
  'Updated At' => '',
  'Updated By' => '',
  'User' => '',
);
