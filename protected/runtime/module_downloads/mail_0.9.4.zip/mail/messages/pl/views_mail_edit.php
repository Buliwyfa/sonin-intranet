<?php
return array (
  'Edit message entry' => 'Edytuj treść wiadomości',
  'Save' => 'Zapisz',
);
