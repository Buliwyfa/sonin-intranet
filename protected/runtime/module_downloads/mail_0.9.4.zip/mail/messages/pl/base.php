<?php
return array (
  'Created At' => 'Utworzono',
  'Created By' => 'Utworzone przez',
  'Is Originator' => '',
  'Last Viewed' => 'Ostatnio oglądane',
  'Message' => 'Wiadomość',
  'Messages' => 'Wiadomości ',
  'Title' => 'Tytuł',
  'Updated At' => 'Zaktualizowana o ',
  'Updated By' => '',
  'User' => 'Użytkownik',
);
