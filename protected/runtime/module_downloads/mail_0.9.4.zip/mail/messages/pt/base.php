<?php
return array (
  'Created At' => '',
  'Created By' => '',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => 'Mensagem',
  'Messages' => '',
  'Title' => 'Título',
  'Updated At' => '',
  'Updated By' => '',
  'User' => 'Usuário',
);
