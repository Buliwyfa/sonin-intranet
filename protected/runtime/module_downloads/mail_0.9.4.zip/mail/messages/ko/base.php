<?php
return array (
  'Created At' => '',
  'Created By' => '',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => '',
  'Messages' => '',
  'Title' => '제목',
  'Updated At' => '',
  'Updated By' => '',
  'User' => '',
);
