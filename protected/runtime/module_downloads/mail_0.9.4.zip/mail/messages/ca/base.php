<?php
return array (
  'Created At' => 'Creat el',
  'Created By' => 'Creat per',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => 'Missatge',
  'Messages' => 'Missatges',
  'Title' => 'Títol',
  'Updated At' => 'Actualitzat el',
  'Updated By' => '',
  'User' => '',
);
