<?php
return array (
  'Created At' => '',
  'Created By' => '',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => '',
  'Messages' => '',
  'Title' => 'Tit',
  'Updated At' => '',
  'Updated By' => '',
  'User' => '',
);
