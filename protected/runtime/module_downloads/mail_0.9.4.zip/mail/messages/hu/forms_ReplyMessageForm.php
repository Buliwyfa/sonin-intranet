<?php
return array (
  'Message' => 'Üzenet',
);
