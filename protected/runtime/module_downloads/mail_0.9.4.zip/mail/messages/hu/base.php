<?php
return array (
  'Created At' => 'Létrehozva',
  'Created By' => 'Létrehozta',
  'Is Originator' => '',
  'Last Viewed' => 'Utoljára megtekintve',
  'Message' => 'Üzenet',
  'Messages' => 'Üzenetek',
  'Title' => 'Naslov',
  'Updated At' => 'Szerkesztve',
  'Updated By' => 'Szerkesztette',
  'User' => 'Felhasználó',
);
