<?php
return array (
  'New message' => 'Új üzenet',
  'Send message' => 'Üzenetküldés',
);
