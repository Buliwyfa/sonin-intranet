<?php
return array (
  'Groups' => 'Csoportok',
  'Members' => 'Tagok',
  'Spaces' => '',
  'User Posts' => '',
);
