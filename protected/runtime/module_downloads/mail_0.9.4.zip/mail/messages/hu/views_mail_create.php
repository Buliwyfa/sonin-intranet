<?php
return array (
  'Add recipients' => '',
  'Close' => 'Zatvori',
  'New message' => '',
  'Send' => 'Beküldés',
);
