<?php
return array (
  'Messages' => 'Üzenetek',
  'New message' => 'Üzenet írása',
  'Show all messages' => 'Összes üzenet',
);
