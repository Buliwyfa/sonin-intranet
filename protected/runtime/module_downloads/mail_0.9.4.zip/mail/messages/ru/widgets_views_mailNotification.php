<?php
return array (
  'Messages' => 'Сообщения',
  'New message' => 'Написать',
  'Show all messages' => 'Показать все сообщения',
);
