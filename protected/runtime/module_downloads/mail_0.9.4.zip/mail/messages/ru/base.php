<?php
return array (
  'Created At' => 'Создано в',
  'Created By' => 'Создано',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => 'Сообщение',
  'Messages' => 'Сообщения',
  'Title' => 'Заголовок',
  'Updated At' => 'Обновлено в',
  'Updated By' => 'Обновлено',
  'User' => 'Пользователь',
);
