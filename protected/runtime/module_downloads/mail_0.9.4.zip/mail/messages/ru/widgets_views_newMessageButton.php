<?php
return array(
	'New message'  => 'Новое сообщение',
	'Send message' => 'Отправить сообщение',
);