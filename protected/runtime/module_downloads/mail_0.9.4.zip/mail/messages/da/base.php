<?php
return array (
  'Created At' => 'Oprettet den',
  'Created By' => 'Oprettet af',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => 'Besked',
  'Messages' => 'Beskeder',
  'Title' => 'Titel',
  'Updated At' => 'Opdateret den',
  'Updated By' => '',
  'User' => 'Bruger',
);
