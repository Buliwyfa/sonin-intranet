<?php
return array (
  'Add more participants to your conversation...' => 'Tilføj flere deltagere til din samtale...',
  'Close' => 'Luk',
  'Send' => 'Send',
);
