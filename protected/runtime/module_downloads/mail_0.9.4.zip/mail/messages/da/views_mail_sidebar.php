<?php
return array (
  'Groups' => 'Grupper',
  'Members' => 'Medlemmer',
  'Spaces' => 'Sider',
  'User Posts' => 'Bruger Opslag',
);
