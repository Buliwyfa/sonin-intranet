<?php
return array (
  'Created At' => 'Gemaakt op',
  'Created By' => 'Gemaakt door',
  'Is Originator' => 'Is beginner',
  'Last Viewed' => 'Laatst weergegeven',
  'Message' => 'Bericht',
  'Messages' => 'Berichten',
  'Title' => 'Titel',
  'Updated At' => 'Geüpdate op',
  'Updated By' => 'Geüpdate door',
  'User' => 'Gebruiker',
);
