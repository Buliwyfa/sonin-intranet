<?php
return array (
  'Add more participants to your conversation...' => 'Voeg meer deelnemers toe aan je conversatie...',
  'Close' => 'Sluiten',
  'Send' => 'Verstuur',
);
