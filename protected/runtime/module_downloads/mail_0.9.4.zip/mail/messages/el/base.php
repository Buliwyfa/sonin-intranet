<?php
return array (
  'Created At' => '',
  'Created By' => '',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => 'Μήνυμα',
  'Messages' => '',
  'Title' => 'Τίτλος',
  'Updated At' => '',
  'Updated By' => '',
  'User' => 'Χρήστης',
);
