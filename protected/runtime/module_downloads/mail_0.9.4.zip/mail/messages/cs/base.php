<?php
return array (
  'Created At' => 'Vytvořeno',
  'Created By' => 'Vytvořil(a)',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => 'Zpráva',
  'Messages' => 'Zprávy',
  'Title' => 'Název',
  'Updated At' => 'Aktualizováno',
  'Updated By' => '',
  'User' => 'Uživatel',
);
