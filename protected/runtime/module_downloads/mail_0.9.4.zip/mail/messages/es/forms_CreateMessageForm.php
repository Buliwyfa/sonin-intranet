<?php
return array (
  'Message' => 'Mensaje',
  'Recipient' => 'Destinatario',
  'Subject' => 'Asunto',
  'You cannot send a email to yourself!' => 'No te puedes enviar mensajes tu mismo!',
);
