<?php
return array (
  'Conversations' => 'Conversaciones',
  'New' => 'Nuevo',
  'New message' => 'Nuevo mensaje',
  'There are no messages yet.' => 'No hay mensajes aún.',
);
