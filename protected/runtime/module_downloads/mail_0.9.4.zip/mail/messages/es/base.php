<?php
return array (
  'Created At' => 'Creado en',
  'Created By' => 'Creado por',
  'Is Originator' => 'Es Originario',
  'Last Viewed' => 'Visto por última vez',
  'Message' => 'Mensaje',
  'Messages' => 'Mensajes',
  'Title' => 'Titulo',
  'Updated At' => 'Actualizado en',
  'Updated By' => 'Actualizado por',
  'User' => 'Usuario',
);
