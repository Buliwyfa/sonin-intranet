<?php
return array (
  'New message' => 'پیغام جدید',
  'Send message' => 'ارسال پیغام',
);
