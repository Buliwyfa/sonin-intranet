<?php
return array (
  'Created At' => 'ایجادشده در',
  'Created By' => 'ایجادشده توسط',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => 'پیغام',
  'Messages' => 'پیام‌ها',
  'Title' => 'عنوان',
  'Updated At' => 'به‌روزرسانی‌شده در',
  'Updated By' => 'بروزرساني توسط',
  'User' => 'کاربر',
);
