<?php
return array (
  'Recipient' => '受信者',
  'You cannot send a email to yourself!' => '',
);
