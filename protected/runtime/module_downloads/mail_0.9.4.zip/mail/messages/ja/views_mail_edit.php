<?php
return array (
  'Edit message entry' => '',
  'Save' => '保存',
);
