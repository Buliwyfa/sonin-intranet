<?php
return array (
  'Created At' => '作成',
  'Created By' => '作成者',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => 'メッセージ',
  'Messages' => 'メッセージ',
  'Title' => 'タイトル',
  'Updated At' => '更新',
  'Updated By' => '',
  'User' => 'ユーザー',
);
