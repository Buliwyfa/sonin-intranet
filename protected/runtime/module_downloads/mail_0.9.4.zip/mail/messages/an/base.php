<?php
return array (
  'Created At' => '',
  'Created By' => '',
  'Is Originator' => '',
  'Last Viewed' => '',
  'Message' => 'Zpráva',
  'Messages' => '',
  'Title' => 'Titulek',
  'Updated At' => '',
  'Updated By' => '',
  'User' => '',
);
