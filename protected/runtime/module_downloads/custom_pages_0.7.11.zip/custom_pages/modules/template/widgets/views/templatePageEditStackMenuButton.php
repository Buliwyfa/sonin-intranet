
<div style="display:inline-block;height:0px;overflow:visible;vertical-align:middle;">
<?= humhub\modules\custom_pages\modules\template\widgets\TemplatePageEditButton::widget(); ?>
</div>