<?php
return array (
  '<strong>Create</strong> page' => '<strong>Opprett</strong> side',
  '<strong>Edit</strong> page' => '<strong>Rediger</strong> side',
  'Content' => 'Innhold',
  'Default sort orders scheme: 100, 200, 300, ...' => 'Standard sorterings måte: 100, 200, 300, ...',
  'Delete' => 'Slett',
  'Next' => 'Neste',
  'Page title' => 'Side titel',
  'Save' => 'Lagre',
  'Sort Order' => 'Sorterings rekkefølge ',
  'URL' => 'URL',
);
