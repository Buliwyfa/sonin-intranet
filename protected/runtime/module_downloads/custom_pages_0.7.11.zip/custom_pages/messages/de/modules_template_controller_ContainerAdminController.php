<?php
/**
 * Created by PhpStorm.
 * User: 001101
 * Date: 25.01.2017
 * Time: 03:47
 */
return array (
    'Here you can manage your template container elements.' =>  'Hier können Sie ihre Container Vorlagen Elemente verwalten',
);