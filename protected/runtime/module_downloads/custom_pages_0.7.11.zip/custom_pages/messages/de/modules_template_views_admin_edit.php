<?php
/**
 * Created by PhpStorm.
 * User: 001101
 * Date: 25.01.2017
 * Time: 02:30
 */

return array (
    'Save' => 'Speichern',
    'Type' => 'Typ',
    'Create new {type}' => '{type} erstellen',
    'Edit template \'{templateName}\'' => 'Vorlage \'{templateName}\' bearbeiten',
	'page' => 'Inhalt',
    'snippet' => 'Schnipsel',
    'layout' => 'Layout',
);