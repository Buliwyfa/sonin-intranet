<?php
/**
 * Created by PhpStorm.
 * User: 001101
 * Date: 25.01.2017
 * Time: 01:32
 */

return array (
    'Only visible for admins' => 'Nur für Admins sichtbar',
    'Content' => 'Inhalt',
    'Navigation' => 'Navigation',
    'Open in new window' => 'In neuem Fenster öffnen',
    'page' => 'Inhalt',
    'snippet' => 'Schnipsel',
    'layout' => 'Layout',
);