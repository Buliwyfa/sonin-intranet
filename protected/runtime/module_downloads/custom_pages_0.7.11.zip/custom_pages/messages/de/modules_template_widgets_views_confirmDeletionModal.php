<?php
/**
 * Created by PhpStorm.
 * User: 001101
 * Date: 25.01.2017
 * Time: 02:17
 */
return array (
    'Are you sure you want to delete this container item?' => 'Willst du dieses Container Element wirklich löschen?',
);