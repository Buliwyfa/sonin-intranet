<?php
/**
 * Created by PhpStorm.
 * User: 001101
 * Date: 25.01.2017
 * Time: 01:35
 */
return array (
    'Open in new window' => 'In neuem Fenster öffnen',
    'Content' => 'Typ',
    'Only visible for space admins' => 'Nur für Admins sichtbar',
    'page' => 'Seite',
);