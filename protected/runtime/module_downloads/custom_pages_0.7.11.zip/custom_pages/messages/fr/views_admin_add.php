<?php
return array (
  '<strong>Add</strong> new page' => '<strong>Ajouter</strong> une nouvelle page',
);
