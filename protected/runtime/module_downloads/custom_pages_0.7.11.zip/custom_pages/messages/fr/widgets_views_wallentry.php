<?php
return array (
  'Open page...' => 'Ouvrir la page...',
);
