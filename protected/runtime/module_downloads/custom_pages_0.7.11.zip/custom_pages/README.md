## Description
Allows admins to create custom pages (html or markdown) or external links to various navigations (e.g. top navigation, account menu).

__Status:__ beta   
__Module website:__ <https://github.com/humhub/humhub-modules-custom-pages>    
__Author:__ luke    
__Author website:__ [humhub.org](http://humhub.org)    


## Changelog

<https://github.com/humhub/humhub-modules-custom-pages/commits/master>

## Bugtracker

<https://github.com/humhub/humhub-modules-custom-pages/issues>
