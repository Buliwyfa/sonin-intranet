<?php
return array (
  'Description for the wall entry.' => 'Descrição para entrada no mural.',
  'Parent Folder ID' => 'ID da Pasta Pai',
  'Title' => 'Título',
);
