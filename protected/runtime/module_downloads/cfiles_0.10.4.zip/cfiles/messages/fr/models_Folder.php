<?php
return array (
  'Description for the wall entry.' => 'Description pour l\'affichage sur le mur.',
  'Parent Folder ID' => 'ID dossier parent',
  'Title' => 'Titre',
);
