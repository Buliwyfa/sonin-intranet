<?php
return array (
  'Description for the wall entry.' => 'Beschreibung der Wandeingabe.',
  'Parent Folder ID' => 'ID des übergeordneten Ordners',
  'Title' => 'Titel',
);
