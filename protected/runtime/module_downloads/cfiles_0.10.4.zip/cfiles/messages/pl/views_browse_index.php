<?php
return array (
  'Could not save file %title%. ' => 'Nie można zapisać pliku %title%.',
);
