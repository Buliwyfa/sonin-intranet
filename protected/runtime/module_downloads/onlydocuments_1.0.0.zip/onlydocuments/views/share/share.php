<?=

\humhub\modules\onlydocuments\widgets\ShareWidget::widget([
    'file' => $file,
    'mode' => $mode,
]);
?>