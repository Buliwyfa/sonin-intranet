<?php
return array (
  'Task' => 'Opgave',
);
