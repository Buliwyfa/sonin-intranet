<?php
return array (
  'Assigned user(s)' => 'Tildelt(e) bruger(e)',
  'Deadline' => 'Deadline',
  'Tasks' => 'Opgaver',
  'Title' => 'Titel',
);
