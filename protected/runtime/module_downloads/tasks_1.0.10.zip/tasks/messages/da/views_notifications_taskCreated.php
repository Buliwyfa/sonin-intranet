<?php
return array (
  '{userName} created a new task {task}.' => '{userName} oprettede en ny opgave {task}.',
);
