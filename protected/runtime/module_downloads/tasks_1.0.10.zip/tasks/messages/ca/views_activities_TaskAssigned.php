<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} ha sigut assignat a la tasca {task}.',
);
