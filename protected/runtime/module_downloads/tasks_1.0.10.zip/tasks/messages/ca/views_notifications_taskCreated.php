<?php
return array (
  '{userName} created a new task {task}.' => '{userName} ha creat la nova tasca {task}.',
);
