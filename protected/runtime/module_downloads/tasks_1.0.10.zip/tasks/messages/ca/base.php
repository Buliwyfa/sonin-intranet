<?php
return array (
  'Assigned user(s)' => '',
  'Deadline' => '',
  'Tasks' => 'Tasques',
  'Title' => 'Títol',
);
