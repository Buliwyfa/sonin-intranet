<?php
return array (
  '<strong>Create</strong> new task' => '',
  '<strong>Edit</strong> task' => '',
  'Assign users' => '',
  'Cancel' => 'Cancel·la',
  'Deadline' => '',
  'Save' => 'Desa',
  'What is to do?' => '',
);
