<?php
return array (
  'Assigned user(s)' => '',
  'Deadline' => '',
  'Tasks' => 'Úkoly',
  'Title' => 'Název',
);
