<?php
return array (
  'Click, to finish this task' => 'Click om deze taak te voltooien',
  'This task is already done. Click to reopen.' => 'Deze taak is al voltooid. Klik om als onvoltooid te markeren.',
);
