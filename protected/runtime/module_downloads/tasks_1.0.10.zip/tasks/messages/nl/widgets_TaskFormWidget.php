<?php
return array (
  'Create' => 'Maak',
);
