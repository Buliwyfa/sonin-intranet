<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} gekoppeld aan taak {task}.',
);
