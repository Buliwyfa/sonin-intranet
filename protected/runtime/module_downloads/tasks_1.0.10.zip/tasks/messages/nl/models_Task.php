<?php
return array (
  'Task' => 'Taak',
);
