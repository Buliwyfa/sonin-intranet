<?php
return array (
  '<b>There are no tasks yet!</b>' => '<b>Здесь нет пока задач!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Задач пока нет!</b><br>Будьте первым в создании...',
  'Assigned to me' => 'Назначенное для меня',
  'Back to stream' => 'Вернуться в поток',
  'Created by me' => 'Создано мной',
  'Creation time' => 'Время создания',
  'Filter' => 'Фильтр',
  'Last update' => 'Последнее обновление',
  'No tasks found which matches your current filter(s)!' => 'Нет задач, соответствующих вашему фильтру!',
  'Nobody assigned' => 'Никто не назначен',
  'Sorting' => 'Сортировка',
  'State is finished' => 'Статус завершено',
  'State is open' => 'Статус открыто',
);
