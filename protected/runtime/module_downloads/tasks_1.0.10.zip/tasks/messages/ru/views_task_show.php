<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Подтвердить</strong> удаление',
  'Add Task' => 'Добавить задачу',
  'Cancel' => 'Отменить',
  'Delete' => 'Удалить',
  'Do you really want to delete this task?' => 'Вы действительно хотите удалить эту задачу?',
  'No open tasks...' => 'Нет открытых задач ...',
  'completed tasks' => 'выполненные задачи',
);
