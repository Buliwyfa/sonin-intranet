<?php
return array (
  'Assigned user(s)' => 'Назначенный пользователь (и)',
  'Deadline' => 'Предельный срок',
  'Tasks' => 'Задачи',
  'Title' => 'Наименование',
);
