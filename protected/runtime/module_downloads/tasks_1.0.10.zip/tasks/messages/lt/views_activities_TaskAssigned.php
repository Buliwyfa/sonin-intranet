<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} priskirtas užduočiai {task}.',
);
