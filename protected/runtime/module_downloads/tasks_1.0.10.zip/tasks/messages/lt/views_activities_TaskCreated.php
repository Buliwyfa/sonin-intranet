<?php
return array (
  '{userName} created task {task}.' => '{userName} sukūrė užduotį {task}.',
);
