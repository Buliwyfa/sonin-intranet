<?php
return array (
  'Create' => 'Sukurti',
);
