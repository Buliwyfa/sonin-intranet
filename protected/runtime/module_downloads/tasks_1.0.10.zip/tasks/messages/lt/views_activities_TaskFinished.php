<?php
return array (
  '{userName} finished task {task}.' => '{userName} įvykdė užduotį {task}.',
);
