<?php
return array (
  '<b>There are no tasks yet!</b>' => '<b>Kol kas nėra užduočių!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Kol kas nėra užduočių!</b><br>Būkite pirmas...',
  'Assigned to me' => 'Priskirtas man',
  'Created by me' => 'Mano sukurtas',
  'Creation time' => 'Sukūrimo laikas',
  'Filter' => 'Filtras',
  'Last update' => 'Paskutinis atnaujinimas',
  'Nobody assigned' => 'Niekam nepriskirtas',
  'Sorting' => 'Rūšiavimas',
  'State is finished' => 'Būsena baigta',
  'State is open' => 'Atvira būsena',
);
