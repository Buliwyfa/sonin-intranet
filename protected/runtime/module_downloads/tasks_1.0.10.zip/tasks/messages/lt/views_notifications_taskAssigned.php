<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} priskyrė Jus užduočiai {task}.',
);
