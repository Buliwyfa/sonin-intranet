<?php
return array (
  '<strong>Create</strong> new task' => '',
  '<strong>Edit</strong> task' => '',
  'Assign users' => '',
  'Cancel' => '',
  'Deadline' => '',
  'Save' => 'บันทึก',
  'What is to do?' => '',
);
