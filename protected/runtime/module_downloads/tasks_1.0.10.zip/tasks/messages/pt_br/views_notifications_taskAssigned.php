<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} atribuiu a você a tarefa {task}.',
);
