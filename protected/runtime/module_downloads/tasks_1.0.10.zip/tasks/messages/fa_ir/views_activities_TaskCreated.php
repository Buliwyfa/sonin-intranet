<?php
return array (
  '{userName} created task {task}.' => '{userName} {task} را ایجاد کرد.',
);
