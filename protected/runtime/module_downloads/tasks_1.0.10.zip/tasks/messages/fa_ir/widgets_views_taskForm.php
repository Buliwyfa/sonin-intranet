<?php
return array (
  'Assign users to this task' => 'کاربرانی که این کار به آن‌ها سپرده‌شده‌است',
  'Deadline for this task?' => 'فرصت نهایی برای انجام این کار؟',
  'Preassign user(s) for this task.' => 'کاربران مسئول برای این کار را از پیش تعیین کنید.',
  'What to do?' => 'چه عملی انجام شود؟',
);
