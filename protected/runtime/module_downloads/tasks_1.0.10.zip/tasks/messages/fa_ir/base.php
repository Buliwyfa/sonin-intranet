<?php
return array (
  'Assigned user(s)' => 'كاربران اختصاص داده شده',
  'Deadline' => 'آخرين مهلت',
  'Tasks' => 'کارها',
  'Title' => 'عنوان',
);
