<?php
return array (
  'Task' => 'وظيفه',
);
