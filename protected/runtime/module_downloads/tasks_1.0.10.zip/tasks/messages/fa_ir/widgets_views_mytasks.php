<?php
return array (
  '<strong>My</strong> tasks' => 'کارهای <strong>من</strong>',
  'From space: ' => 'از انجمن:',
);
