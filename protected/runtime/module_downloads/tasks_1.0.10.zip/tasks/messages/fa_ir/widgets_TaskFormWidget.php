<?php
return array (
  'Create' => 'ایجاد',
);
