<?php
return array (
  '{userName} finished task {task}.' => '',
);
