<?php
return array (
  '<strong>Confirm</strong> deleting' => '',
  'Add Task' => '',
  'Cancel' => 'Cancelar',
  'Delete' => 'Eliminar',
  'Do you really want to delete this task?' => '',
  'No open tasks...' => '',
  'completed tasks' => '',
);
