<?php
return array (
  '<b>There are no tasks yet!</b>' => '<b>Non ci sono altre attività per ora!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Non ci sono ancora attività!</b><br>Creane una per primo...',
  'Assigned to me' => 'Assegnate a me',
  'Back to stream' => 'Torna allo stream',
  'Created by me' => 'Create da me',
  'Creation time' => 'Data di creazione',
  'Filter' => 'Filtro',
  'Last update' => 'Ultimo aggiornamento',
  'No tasks found which matches your current filter(s)!' => 'Nessun\'attività trovata che rispetti i tuoi filtri!',
  'Nobody assigned' => 'Non assegnate',
  'Sorting' => 'Ordinamento',
  'State is finished' => 'Lo stato è completato',
  'State is open' => 'Lo stato è aperto',
);
