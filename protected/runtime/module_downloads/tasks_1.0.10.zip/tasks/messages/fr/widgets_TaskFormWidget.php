<?php
return array (
  'Create' => 'Créer',
);
