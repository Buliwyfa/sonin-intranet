<?php
return array (
  '{userName} finished task {task}.' => '{userName} a fini la tâche {task}.',
);
