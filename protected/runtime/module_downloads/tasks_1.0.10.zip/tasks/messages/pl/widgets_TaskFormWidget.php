<?php
return array (
  'Create' => 'Utwórz ',
);
