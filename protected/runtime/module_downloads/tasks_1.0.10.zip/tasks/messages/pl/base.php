<?php
return array (
  'Assigned user(s)' => 'Przypisani użytkownicy',
  'Deadline' => 'Termin końcowy',
  'Tasks' => 'Zadania ',
  'Title' => 'Tytuł',
);
