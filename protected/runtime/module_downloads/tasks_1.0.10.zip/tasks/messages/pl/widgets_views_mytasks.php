<?php
return array (
  '<strong>My</strong> tasks' => '<strong>Moje</strong> zadania',
  'From space: ' => 'Ze strefy: ',
);
