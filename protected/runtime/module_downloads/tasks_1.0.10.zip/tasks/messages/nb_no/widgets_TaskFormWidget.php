<?php
return array (
  'Create' => 'Lag',
);
