<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Bekreft</strong> sletting',
  'Add Task' => 'Legg til oppgave',
  'Cancel' => 'Avbryt',
  'Delete' => 'Slett',
  'Do you really want to delete this task?' => 'Ønsker du virkelig og slette denne oppgaven?',
  'No open tasks...' => 'Ingen åpne oppgaver...',
  'completed tasks' => 'fullførte oppgaver',
);
