<?php
return array (
  'Click, to finish this task' => 'Trykk for og fullføre oppgaven',
  'This task is already done. Click to reopen.' => 'Denne oppgaven er allerede fullført. Trykk for og gjenåpne.',
);
