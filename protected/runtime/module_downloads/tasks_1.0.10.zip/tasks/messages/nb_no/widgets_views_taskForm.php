<?php
return array (
  'Assign users to this task' => 'Tilknytt brukere denne oppgaven',
  'Deadline for this task?' => 'Frist for fullføring?',
  'Preassign user(s) for this task.' => 'Legg til bruker(e) på forhånd.',
  'What to do?' => 'Hva skal gjøres?',
);
