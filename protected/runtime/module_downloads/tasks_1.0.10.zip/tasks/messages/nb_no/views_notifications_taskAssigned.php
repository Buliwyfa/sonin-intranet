<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} tildelte deg en oppgave {task}.',
);
