<?php
return array (
  'Assigned user(s)' => 'Usuario(s) asignado(s)',
  'Deadline' => 'Fecha límite',
  'Tasks' => 'Tareas',
  'Title' => 'Título',
);
