<?php
return array (
  'Task' => 'Tarea',
);
