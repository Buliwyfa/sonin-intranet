<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} te asignó a la tarea {task}.',
);
