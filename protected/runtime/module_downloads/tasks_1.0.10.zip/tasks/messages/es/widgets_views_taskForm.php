<?php
return array (
  'Assign users to this task' => 'Asignar usuarios a esta tarea',
  'Deadline for this task?' => '¿La fecha límite para esta tarea?',
  'Preassign user(s) for this task.' => 'Asignar usuario(s) a esta tarea',
  'What to do?' => '¿Que hacer?',
);
