<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Löschen</strong> bestätigen',
  'Add Task' => 'Aufgabe erstellen',
  'Cancel' => 'Abbrechen',
  'Delete' => 'Löschen',
  'Do you really want to delete this task?' => 'Möchtest Du diese Aufgabe wirklich löschen?',
  'No open tasks...' => 'Keine offenen Aufgaben...',
  'completed tasks' => 'abgeschlossene Aufgaben',
);
