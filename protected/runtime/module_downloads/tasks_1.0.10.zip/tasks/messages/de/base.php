<?php
return array (
  'Assigned user(s)' => 'Zugewiesene Benutzer',
  'Deadline' => 'Termin',
  'Tasks' => 'Aufgaben',
  'Title' => 'Titel',
);
