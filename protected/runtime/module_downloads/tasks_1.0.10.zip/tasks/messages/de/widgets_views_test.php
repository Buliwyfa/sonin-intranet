<?php
return array (
  'Do you want to handle this task?' => 'Willst Du diese Aufgabe übernehmen?',
  'I do it!' => 'Ich mach es!',
);
