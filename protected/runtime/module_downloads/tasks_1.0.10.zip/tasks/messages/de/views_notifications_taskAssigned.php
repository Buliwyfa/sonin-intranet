<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} hat dich der Aufgabe »{task}« zugeordnet.',
);
