<?php
return array (
  'Task' => 'Aufgabe',
);
