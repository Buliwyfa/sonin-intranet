<?php
return array (
  'Assign users to this task' => 'Dieser Aufgabe Benutzer zuordnen',
  'Deadline for this task?' => 'Frist für die Erledigung dieser Aufgabe?',
  'Preassign user(s) for this task.' => 'Benutzer für diese Aufgabe vorauswählen',
  'What to do?' => 'Was ist zu tun?',
);
