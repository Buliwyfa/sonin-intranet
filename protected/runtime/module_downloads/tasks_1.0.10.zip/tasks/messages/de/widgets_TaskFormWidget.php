<?php
return array (
  'Create' => 'Erstellen',
);
