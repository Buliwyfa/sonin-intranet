<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} wurde Aufgabe »{task}« zugeordnet.',
);
