<?php
return array (
  'Assigned user(s)' => '',
  'Deadline' => '',
  'Tasks' => 'タスク',
  'Title' => 'タイトル',
);
